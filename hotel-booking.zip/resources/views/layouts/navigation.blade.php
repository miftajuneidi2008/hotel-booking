<nav x-data="{ open: false }" class="bg-white border-b border-gray-100">
    <!-- Primary Navigation Menu -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <div class="flex">
                <!-- Logo -->
                <div class="shrink-0 flex items-center">
                    <a href="{{ route('dashboard') }}">
                        <x-application-logo class="block h-9 w-auto fill-current text-gray-800" />
                    </a>
                </div>

                <!-- Navigation Links -->
                <div class="hidden space-x-8 sm:-my-px sm:ms-10 sm:flex">
                    <x-nav-link :href="route('dashboard')" :active="request()->routeIs('dashboard')">
                        {{ __('Dashboard') }}
                    </x-nav-link>
                    @can('manage-bookings')
                        <x-nav-link :href="route('staff.front-desk')" :active="request()->routeIs('staff.front-desk')">
                            {{ __('Front desk') }}
                        </x-nav-link>
                        <x-nav-link :href="route('staff.bookings.index')" :active="request()->routeIs('staff.bookings.*')">
                            {{ __('Bookings') }}
                        </x-nav-link>
                        <x-nav-link :href="route('staff.calendar')" :active="request()->routeIs('staff.calendar')">
                            {{ __('Calendar') }}
                        </x-nav-link>
                        <x-nav-link :href="route('staff.groups.index')" :active="request()->routeIs('staff.groups.*')">
                            {{ __('Groups') }}
                        </x-nav-link>
                        <x-nav-link :href="route('staff.cash-summary')" :active="request()->routeIs('staff.cash-summary*')">
                            {{ __('Cash summary') }}
                        </x-nav-link>
                        <x-nav-link :href="route('staff.invoices.index')" :active="request()->routeIs('staff.invoices.*')">
                            {{ __('Invoices') }}
                        </x-nav-link>
                    @endcan
                    @cannot('manage-bookings')
                        <x-nav-link :href="route('my-bookings.index')" :active="request()->routeIs('my-bookings.*')">
                            {{ __('My bookings') }}
                        </x-nav-link>
                    @endcannot
                    @can('manage-property')
                        <x-nav-link :href="route('admin.rooms.index')" :active="request()->routeIs('admin.rooms.*')">
                            {{ __('Rooms') }}
                        </x-nav-link>
                        <x-nav-link :href="route('admin.room-types.index')" :active="request()->routeIs('admin.room-types.*')">
                            {{ __('Room types') }}
                        </x-nav-link>
                        <x-nav-link :href="route('staff.reports.daily')" :active="request()->routeIs('staff.reports.*')">
                            {{ __('Reports') }}
                        </x-nav-link>
                    @endcan
                </div>
            </div>

            <!-- Settings Dropdown -->
            <div class="hidden sm:flex sm:items-center sm:ms-6">
                <x-notification-bell />

                <x-dropdown align="right" width="48">
                    <x-slot name="trigger">
                        <button class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition ease-in-out duration-150">
                            <div>{{ Auth::user()->name }}</div>

                            <div class="ms-1">
                                <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </button>
                    </x-slot>

                    <x-slot name="content">
                        <x-dropdown-link :href="route('profile.edit')">
                            {{ __('Profile') }}
                        </x-dropdown-link>

                        @can('manage-settings')
                            <x-dropdown-link :href="route('admin.settings.tax.edit')">
                                {{ __('Tax settings') }}
                            </x-dropdown-link>
                        @endcan

                        <!-- Authentication -->
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf

                            <x-dropdown-link :href="route('logout')"
                                    onclick="event.preventDefault();
                                                this.closest('form').submit();">
                                {{ __('Log Out') }}
                            </x-dropdown-link>
                        </form>
                    </x-slot>
                </x-dropdown>
            </div>

            <!-- Hamburger -->
            <div class="-me-2 flex items-center sm:hidden">
                <button @click="open = ! open" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 focus:text-gray-500 transition duration-150 ease-in-out">
                    <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                        <path :class="{'hidden': open, 'inline-flex': ! open }" class="inline-flex" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                        <path :class="{'hidden': ! open, 'inline-flex': open }" class="hidden" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <!-- Responsive Navigation Menu -->
    <div :class="{'block': open, 'hidden': ! open}" class="hidden sm:hidden">
        <div class="pt-2 pb-3 space-y-1">
            <x-responsive-nav-link :href="route('dashboard')" :active="request()->routeIs('dashboard')">
                {{ __('Dashboard') }}
            </x-responsive-nav-link>
            @can('manage-bookings')
                <x-responsive-nav-link :href="route('staff.front-desk')" :active="request()->routeIs('staff.front-desk')">
                    {{ __('Front desk') }}
                </x-responsive-nav-link>
                <x-responsive-nav-link :href="route('staff.bookings.index')" :active="request()->routeIs('staff.bookings.*')">
                    {{ __('Bookings') }}
                </x-responsive-nav-link>
                <x-responsive-nav-link :href="route('staff.calendar')" :active="request()->routeIs('staff.calendar')">
                    {{ __('Calendar') }}
                </x-responsive-nav-link>
                <x-responsive-nav-link :href="route('staff.groups.index')" :active="request()->routeIs('staff.groups.*')">
                    {{ __('Groups') }}
                </x-responsive-nav-link>
                <x-responsive-nav-link :href="route('staff.cash-summary')" :active="request()->routeIs('staff.cash-summary*')">
                    {{ __('Cash summary') }}
                </x-responsive-nav-link>
                <x-responsive-nav-link :href="route('staff.invoices.index')" :active="request()->routeIs('staff.invoices.*')">
                    {{ __('Invoices') }}
                </x-responsive-nav-link>
            @endcan
            @cannot('manage-bookings')
                <x-responsive-nav-link :href="route('my-bookings.index')" :active="request()->routeIs('my-bookings.*')">
                    {{ __('My bookings') }}
                </x-responsive-nav-link>
            @endcannot
            @can('manage-property')
                <x-responsive-nav-link :href="route('admin.rooms.index')" :active="request()->routeIs('admin.rooms.*')">
                    {{ __('Rooms') }}
                </x-responsive-nav-link>
                <x-responsive-nav-link :href="route('admin.room-types.index')" :active="request()->routeIs('admin.room-types.*')">
                    {{ __('Room types') }}
                </x-responsive-nav-link>
                <x-responsive-nav-link :href="route('staff.reports.daily')" :active="request()->routeIs('staff.reports.*')">
                    {{ __('Reports') }}
                </x-responsive-nav-link>
            @endcan
        </div>

        <!-- Responsive Settings Options -->
        <div class="pt-4 pb-1 border-t border-gray-200">
            <div class="px-4">
                <div class="font-medium text-base text-gray-800">{{ Auth::user()->name }}</div>
                <div class="font-medium text-sm text-gray-500">{{ Auth::user()->email }}</div>
            </div>

            <div class="mt-3 space-y-1">
                <x-responsive-nav-link :href="route('notifications.index')">
                    {{ __('Notifications') }}
                </x-responsive-nav-link>

                @can('manage-settings')
                    <x-responsive-nav-link :href="route('admin.settings.tax.edit')">
                        {{ __('Tax settings') }}
                    </x-responsive-nav-link>
                @endcan

                <x-responsive-nav-link :href="route('profile.edit')">
                    {{ __('Profile') }}
                </x-responsive-nav-link>

                <!-- Authentication -->
                <form method="POST" action="{{ route('logout') }}">
                    @csrf

                    <x-responsive-nav-link :href="route('logout')"
                            onclick="event.preventDefault();
                                        this.closest('form').submit();">
                        {{ __('Log Out') }}
                    </x-responsive-nav-link>
                </form>
            </div>
        </div>
    </div>
</nav>
