<?php

namespace App\Http\Controllers\Staff;

use App\Enums\PaymentMethod;
use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Services\CashSummaryService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

/**
 * Daily cash summary per user, for closing the day (FR-23).
 * A receptionist sees their own cash; the owner and managers can see everybody's.
 */
class CashSummaryController extends Controller
{
    public function __construct(private readonly CashSummaryService $summary) {}

    public function index(Request $request): View
    {
        return view('staff.cash-summary.index', $this->data($request) + [
            'staff' => Gate::allows('viewAllSummaries', Payment::class) ? $this->summary->staff() : collect(),
        ]);
    }

    /** A clean page for printing the closing sheet. */
    public function print(Request $request): View
    {
        return view('staff.cash-summary.print', $this->data($request) + [
            'property' => config('hotel.name', config('app.name')),
            'printedBy' => $request->user()->name,
        ]);
    }

    /** @return array<string, mixed> */
    private function data(Request $request): array
    {
        Gate::authorize('viewSummary', Payment::class);

        $input = $request->validate([
            'date' => ['nullable', 'date'],
            'user' => ['nullable', 'integer', Rule::exists('users', 'id')],
        ]);

        $seesAll = Gate::allows('viewAllSummaries', Payment::class);
        $date = isset($input['date']) ? date('Y-m-d', strtotime((string) $input['date'])) : $this->summary->today();

        // Anyone below manager only ever sees their own cash.
        $userId = $seesAll ? ($input['user'] ?? null) : $request->user()->id;

        return [
            'summary' => $this->summary->day($date, $userId ? (int) $userId : null),
            'date' => $date,
            'userId' => $userId ? (int) $userId : null,
            'seesAll' => $seesAll,
            'timezone' => $this->summary->timezone(),
            'methods' => PaymentMethod::cases(),
        ];
    }
}
